# FFCF
Federated Clustering Algorithm based on a Fuzzy Clustering Feature Vector
